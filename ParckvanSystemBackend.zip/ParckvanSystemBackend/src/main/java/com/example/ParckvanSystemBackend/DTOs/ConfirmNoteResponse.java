package com.example.ParckvanSystemBackend.DTOs;

public class ConfirmNoteResponse {
    public int code;
    public String message ;
}
