package com.example.ParckvanSystemBackend.DTOs;

public class DeleteResponse {
    public int code;
    public String message;

}
