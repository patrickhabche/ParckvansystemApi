package com.example.ParckvanSystemBackend.DTOs;

import com.example.ParckvanSystemBackend.Entities.Note;

public class NoteConfirmationRequest {
    public int noteId;
    public float deposit;
}
