package com.example.ParckvanSystemBackend.DTOs;

import java.time.LocalDateTime;

public class NoteFilter {
    public String customerName;
    public LocalDateTime checkin;
    public LocalDateTime checkout;
    public String phone;

}
