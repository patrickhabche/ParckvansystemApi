package com.example.ParckvanSystemBackend.DTOs;

import com.example.ParckvanSystemBackend.Entities.Note;

public class NoteSingleResponse {
    public int code ;
    public String message;
    public Note result;
}
