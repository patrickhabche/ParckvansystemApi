package com.example.ParckvanSystemBackend.DTOs;

public class PagingNoteRequest {
    public NoteFilter filter;
    public int pageSize;
    public int pageNumber;
}
