package com.example.ParckvanSystemBackend.DTOs;

public class PagingReservationRequest {
    public ReservationFilter filter;
    public int pageSize;
    public int pageNumber;
}