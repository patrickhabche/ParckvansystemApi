package com.example.ParckvanSystemBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParckvanSystemBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParckvanSystemBackendApplication.class, args);
	}

}
