//package com.example.ParckvanSystemBackend.Repositories;
//
//import com.example.ParckvanSystemBackend.Entities.Role;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface RoleRepository extends JpaRepository<Role, Long> {
//    Role findByName(String name);
//}