package com.example.ParckvanSystemBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParckvanSystemBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
